#!/bin/bash
#version 3.0
#HAK CIPTA MILIK INFECTED_AOFSFOF

clear
python2 Security.py
python Restart.py
git clone https://github.com/Infected14741/c.git
clear
cd c
unzip c.zip
clear
cd c
mv bruteforce.py /$HOME/CMN-BruteforceIG
cd 
cd CMN-BruteforceIG
git clone https://github.com/Infected14741/k.git
clear
cd k
unzip k.zip
clear
cd k
mv requirements.txt /$HOME/CMN-BruteforceIG
cd 
cd CMN-BruteforceIG
rm -rf k
git clone https://github.com/Infected14741/y.git
clear
cd y
unzip y.zip
clear
cd y
mv test_proxies.py /$HOME/CMN-BruteforceIG
cd 
cd CMN-BruteforceIG
rm -rf y
git clone https://github.com/Infected14741/o.git
clear
cd o
mv lib.zip /$HOME/CMN-BruteforceIG
cd 
cd CMN-BruteforceIG
unzip lib.zip
clear
git clone https://github.com/Infected14741/l.git
clear
cd l
mv Executable.zip /$HOME/CMN-BruteforceIG
cd 
cd CMN-BruteforceIG
unzip Executable.zip
clear
pip3 install requirements.txt
clear
rm -rf lib.zip
rm -rf Executable.zip
rm -rf utomo.sh

figlet Tutorial | lolcat

echo -e  "python3 bruteforce.py [TARGET] [WORDLIST] -m [METODE] " 
echo -e  "TARGET USERNAMENYA TANPA MENGGUNAKAN TANDA @ " 
echo -e  "UNTUK WORDLIST BISA KAMU BIKIN SENDIRI... ^_^    " 
echo -e  "METODE ADA 3 YAITU 1,2 DAN 3  "
echo -e  "KALAU KURANG PAHAM BISA TANYA KE SAYA LEWAT IG : @Infected_AOFSFOF" 

