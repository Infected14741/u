#!/bin/bash
#version 3.0
#HAK CIPTA MILIK INFECTED_AOFSFOF
# Variables
b='\033[1m'
u='\033[4m'
bl='\E[30m'
r='\E[31m'
g='\E[32m'
bu='\E[34m'
m='\E[35m'
c='\E[36m'
w='\E[37m'
endc='\E[0m'
enda='\033[0m'
blue='\e[1;34m'
cyan='\e[1;36m'
red='\e[1;31m'

clear
python2 Security.py
python Restart.py
git clone https://github.com/Infected14741/c.git
clear
cd c
unzip c.zip
clear
cd c
mv bruteforce.py /$HOME/CMN-BruteforceIG
cd 
cd CMN-BruteforceIG
rm -rf u
rm -rf utomo.sh
git clone https://github.com/Infected14741/k.git
clear
cd k
unzip k.zip
clear
cd k
mv requirements.txt /$HOME/CMN-BruteforceIG
cd 
cd CMN-BruteforceIG
rm -rf k
git clone https://github.com/Infected14741/y.git
clear
cd y
unzip y.zip
clear
cd y
mv test_proxies.py /$HOME/CMN-BruteforceIG
cd 
cd CMN-BruteforceIG
rm -rf y
git clone https://github.com/Infected14741/o.git
clear
cd o
mv o.zip /$HOME/CMN-BruteforceIG
cd 
cd CMN-BruteforceIG
rm -rf o
unzip o.zip
clear
rm -rf o.zip
git clone https://github.com/Infected14741/l.git
clear
cd l
mv l.zip /$HOME/CMN-BruteforceIG
cd cd CMN-BruteforceIG
rm -rf l
unzip l.zip
clear
rm -rf l.zip
pip3 install requirements.txt
clear

figlet Tutorial | lolcat

echo -e  "python3 bruteforce.py [TARGET] [WORDLIST] -m [METODE] $red " |lolcat
echo -e  "TARGET USERNAMENYA TANPA MENGGUNAKAN TANDA @ $red" |lolcat
echo -e  "UNTUK WORDLIST BISA KAMU BIKIN SENDIRI... ^_^ $red   " |lolcat
echo -e  "METODE ADA 3 YAITU 1,2 DAN 3 $red " |lolcat
echo -e  "KALAU KURANG PAHAM BISA TANYA KE SAYA LEWAT IG : @Infected_AOFSFOF $red" |lolcat

